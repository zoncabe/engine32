FILE "03_character_3d_collision.bin" BINARY
  TRACK 01 MODE2/2352
    INDEX 01 00:00:00
